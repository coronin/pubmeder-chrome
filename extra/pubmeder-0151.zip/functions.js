function eraseAll() {
  var answer = confirm("Are you sure that you want to clear the local storage?");
  if (answer) {
    localStorage.clear();
  }
  location.reload();
}

function eraseData() {
  //localStorage.clear();
  var answer = confirm("Are you sure that you want to clear new/un-uploaded records?");
  if (answer) {
    for (var i = 1; i < localStorage.length; i++) {
      var TimePattern = /10000000\d{14}/;
      var tempKey = localStorage.key(i);
      if (TimePattern.test(localStorage.getItem(tempKey))) {
      localStorage.removeItem(tempKey);
      }
    }
  }
  location.reload();
}

function showALL() {
  var dotCheck = /\./;
  var pmcCheck = /PMC/;

  var content = '<p>The following is the recent browsing records</p><table style="border:0;"><tr><th> </th><th>ID</th><th style="color:#aaa">Checked Time</th></tr>';

  var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
  var TimePattern = /10000000\d{14}/;
  for (var i = 0; i < localStorage.length; i++) {
    var tempKey = localStorage.key(i);
    var checkedTime = localStorage.getItem(tempKey);
    if (TimePattern.test(checkedTime)) {
      checkedTime = checkedTime.substr(8).replace(/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/,"$2 $3, $1 at $4:$5");
      content = content + '<tr><td style="color:#ccc">' + i + '</td>';
      if (dotCheck.test(tempKey)) {
        content = content + '<td><a href="http://dx.doi.org/' + tempKey + '" target=_blank>doi</a>:<a style="background:#ddd" onclick="EntrezAJAX(\'' + tempKey + '\')">' + tempKey + '</a></td>';
      } else if (pmcCheck.test(tempKey)) {
        content = content + '<td><a href="http://www.ncbi.nlm.nih.gov/pmc/articles/' + tempKey + '/?tool=pubmeder" target=_blank>pmcid</a>:<a style="background:#ddd" onclick="EntrezAJAX(\'' + tempKey + '\')">' + tempKey + '</a></td>';
      } else {
        content = content + '<td><a href="http://www.ncbi.nlm.nih.gov/pubmed/' + tempKey + '/?tool=pubmeder" target=_blank>pmid</a>:<a style="background:#ddd" onclick="EntrezAJAX(\'' + tempKey + '\')">' + tempKey + '</a></td>';
      }
      content = content + '<td><a style="color:#aaa" onclick="EntrezAJAX(\'' + tempKey + '\')">' + m_names[checkedTime.substr(0,2)-1] + checkedTime.substr(2) + '<a></td></tr>';
    }
  }

  content = content + '</table>';
  $("#record-table").html(content);
  $("#record-table").removeClass("Off");
  $("#showALL").addClass("Off");
  $("#hideALL").removeClass("Off");
}

function hideALL() {
  $("#record-table").addClass("Off");
  $("#result").addClass("Off");
  $("#showALL").removeClass("Off");
  $("#hideALL").addClass("Off");
}

function hideMore() {
  $(".moreAbout").addClass("Off");
  $("#AbsButton").removeClass("Off");
}

function loadOptions() {
  var abstractOp = localStorage["abstractOp"];

  // valid abstractOp are No and Yes, default No
  if (abstractOp == undefined || (abstractOp != "No" && abstractOp != "Yes")) {
    abstractOp = "No";
  }

  var select = document.getElementById("abstract");
  for (var i = 0; i < select.children.length; i++) {
    var child = select.children[i];
      if (child.value == abstractOp) {
      child.selected = "true";
      break;
    }
  }
}

function saveOptions() {
  var select = document.getElementById("abstract");
  var choice = select.children[select.selectedIndex].value;
  localStorage["abstractOp"] = choice;
}

function eraseOptions() {
  localStorage.removeItem("abstractOp");
  location.reload();
}

function EntrezAJAX(search_term) {
  $(document).ready(function() {
    args = {'apikey' : 'ab25c21c079653919d9b53213ac8cc6e',
            'db' : 'pubmed',
            'retmax' : '7',
            'term' : search_term};
    $.getJSON('http://entrezajax2.appspot.com/esearch+esummary?callback=?', args, function(data){
      $('#result').html('');
      $.each(data.result, function(i, item){
        var author_list = '';
        for(var j = 0; j < item.AuthorList.length; j ++) {     
          if ( j == 0 ) {
            author_list = '<b>' + item.AuthorList[j].replace(/ (\w)(\w)/g," $1.$2") + "." + '</b>';
          }
          else if ( j == (item.AuthorList.length - 1) ) {
            author_list += ', <b>' + item.AuthorList[j].replace(/ (\w)(\w)/g," $1.$2") + "." + '</b>';
          }
          else {
            author_list += ', ' + item.AuthorList[j].replace(/ (\w)(\w)/g," $1.$2") + ".";
          } 
        }
        if (item.ArticleIds.pmc) {
          var titleLink = '<a target="blank" href="http://www.ncbi.nlm.nih.gov/pmc/articles/' + item.ArticleIds.pmc + '/?tool=pubmeder">' + item.Title + '</a> ';
        } else if (item.ArticleIds.doi) {
          var titleLink = '<a target="blank" href="http://dx.doi.org/' + item.ArticleIds.doi + '">' + item.Title + '</a> ';
        } else {
          var titleLink = '<a target="blank" href="http://www.ncbi.nlm.nih.gov/pubmed/' + item.ArticleIds.pubmed + '/?tool=pubmeder">' + item.Title + '</a> ';
        }
        var html = '<p style="font-size:0.85em;">' + author_list + ' (' + item.PubDate + '). ' + titleLink + item.Source + '.  <i>' + item.Volume + '</i>, ' + item.Pages + '<br/><button id="AbsButton" onclick="eFetch(' + item.ArticleIds.pubmed + ')"> More about </button><a target="blank" style="font-size:0.75em;text-decoration:none;color:#000;" href="http://www.ncbi.nlm.nih.gov/pubmed/' + item.ArticleIds.pubmed + '/?tool=pubmeder">PMID:' + item.ArticleIds.pubmed + '</a></p>';
        $("<div/>").html(html).appendTo('#result');
      });
    });
  });
  $("#result").removeClass("Off");
  $("#found").addClass("Off");
}

function eFetch(pmid) {
  $(document).ready(function() {
    args = {'apikey' : 'ab25c21c079653919d9b53213ac8cc6e',
            'db' : 'pubmed',
            'id' : pmid};
    $.getJSON('http://entrezajax2.appspot.com/efetch?callback=?', args, function(d){
      $('#AbsButton').addClass('Off');
      $.each(d.result, function(i, l){

        var abstract = '<p onclick="hideMore()" class="moreAbout" style="font-size:0.8em;"><b><u>Abstract</u>: </b>' + l.MedlineCitation.Article.Abstract.AbstractText + '</p>';
        $("<div/>").html(abstract).appendTo('#result');

        if (l.MedlineCitation.CommentsCorrectionsList) {
          var ref_list = '<p onclick="hideMore()" class="moreAbout" style="font-size:0.8em;color:#666"><b><u>References</u>: </b>';
          for(var j = 0; j < l.MedlineCitation.CommentsCorrectionsList.length; j ++) {     
            if ( j == 0 ) {
              ref_list += '<a style="text-decoration:none;color:#666;" target="blank" href="http://www.ncbi.nlm.nih.gov/pubmed/' + l.MedlineCitation.CommentsCorrectionsList[j].PMID + '/?tool=pubmeder">' + l.MedlineCitation.CommentsCorrectionsList[j].RefSource.replace(/([a-zA-Z]+). (\d{4})( [A-Z]|;).+/g,"$1 <font style=\"color:#999;\">$2</font>") + '</a>';
            }
            else {
              ref_list += '; <a style="text-decoration:none;color:#666;" target="blank" href="http://www.ncbi.nlm.nih.gov/pubmed/' + l.MedlineCitation.CommentsCorrectionsList[j].PMID + '/?tool=pubmeder">' + l.MedlineCitation.CommentsCorrectionsList[j].RefSource.replace(/([a-zA-Z()]+). (\d{4})( [A-Z]|;).+/g,"$1 <font style=\"color:#999;\">$2</font>") + '</a>';
            }
          }
          ref_list += '</p>';
          $("<div/>").html(ref_list).appendTo('#result');
        }

        if (l.MedlineCitation.Article.GrantList) {
          var grant_list = '<p onclick="hideMore()" class="moreAbout" style="font-size:0.8em;color:#696969"><b><u>Fund By</u>: </b>';
          for(var j = 0; j < l.MedlineCitation.Article.GrantList.length; j ++) {     
            if ( j == 0 ) {
              grant_list += l.MedlineCitation.Article.GrantList[j].Agency + ': ' + l.MedlineCitation.Article.GrantList[j].GrantID;
            }
            else {
              grant_list += '; ' + l.MedlineCitation.Article.GrantList[j].Agency + ': ' + l.MedlineCitation.Article.GrantList[j].GrantID;
            }
          }
          grant_list += '</p>';
          $("<div/>").html(grant_list).appendTo('#result');
        }

        if (l.MedlineCitation.ChemicalList) {
          var keyChem = '<p onclick="hideMore()" class="moreAbout" style="font-size:0.8em;color:#6a6a6a"><b><u>Chemical</u>: </b>';
          for(var j = 0; j < l.MedlineCitation.ChemicalList.length; j ++) {     
            if ( j == 0 ) {
              keyChem += l.MedlineCitation.ChemicalList[j]. NameOfSubstance;
            }
            else {
              keyChem += '; ' + l.MedlineCitation.ChemicalList[j]. NameOfSubstance;
            }
          }
          keyChem += '</p>';
          $("<div/>").html(keyChem).appendTo('#result');
        }

        if (l.MedlineCitation.MeshHeadingList) {
          var keyHead = '<p onclick="hideMore()" class="moreAbout" style="font-size:0.8em;color:#6f6f6f"><b><u>Heading</u>: </b>';
          for(var j = 0; j < l.MedlineCitation.MeshHeadingList.length; j ++) {     
            if ( j == 0 ) {
              keyHead += l.MedlineCitation.MeshHeadingList[j].DescriptorName;
            }
            else {
              keyHead += '; ' + l.MedlineCitation.MeshHeadingList[j].DescriptorName;
            }
          }
          keyHead += '</p>';
          $("<div/>").html(keyHead).appendTo('#result');
        }

      });
    });
  });
}